package com.aiphotographer.app.camera

import com.aiphotographer.app.ai.PhotoMode

/**
 * Provides mode-specific photography advice and suggested settings.
 * Actual hardware application depends on device capabilities.
 */
object PhotoModeHelper {

    data class ModeConfig(
        val title: String,
        val advice: String,
        val suggestedFlash: Int = androidx.camera.core.ImageCapture.FLASH_MODE_OFF,
        val preferFront: Boolean = false
    )

    fun getConfig(mode: PhotoMode): ModeConfig = when (mode) {
        PhotoMode.AUTO -> ModeConfig(
            "Auto",
            "Balanced settings. AI will guide composition and lighting."
        )
        PhotoMode.PORTRAIT -> ModeConfig(
            "Portrait",
            "Focus on the eyes. Soft light from the side or 45° is ideal. Use rule of thirds."
        )
        PhotoMode.LANDSCAPE -> ModeConfig(
            "Landscape",
            "Use a wide view. Keep horizon level. Golden hour light is best."
        )
        PhotoMode.STREET -> ModeConfig(
            "Street",
            "Be ready for decisive moments. Higher shutter preferred when available."
        )
        PhotoMode.NIGHT -> ModeConfig(
            "Night",
            "Stabilize the phone. Prefer available light. Flash can flatten the scene."
        )
        PhotoMode.MACRO -> ModeConfig(
            "Macro",
            "Get close. Tap to focus carefully. Steady hands or support recommended."
        )
        PhotoMode.CINEMATIC -> ModeConfig(
            "Cinematic",
            "Leave look-room in the direction the subject faces. Slight underexposure can help mood."
        )
        PhotoMode.FOOD -> ModeConfig(
            "Food",
            "45° angle or flat-lay. Soft natural light from the side. Avoid harsh overhead flash."
        )
        PhotoMode.SELFIE -> ModeConfig(
            "Selfie",
            "Hold slightly above eye level. Face a soft light source. Smile naturally.",
            preferFront = true
        )
    }
}
