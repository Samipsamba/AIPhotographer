package com.aiphotographer.app

import android.app.Application
import android.util.Log

class AIPhotographerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "AI Photographer initialized")
    }

    companion object {
        const val TAG = "AIPhotographer"
    }
}
