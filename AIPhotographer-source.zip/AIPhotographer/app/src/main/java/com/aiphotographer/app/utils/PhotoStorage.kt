package com.aiphotographer.app.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PhotoStorage {

    private const val FOLDER = "AIPhotographer"

    fun createImageFile(context: Context): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            ?: context.filesDir
        val dir = File(storageDir, FOLDER).apply { if (!exists()) mkdirs() }
        return File(dir, "IMG_${timeStamp}.jpg")
    }

    fun createOutputOptions(context: Context): androidx.camera.core.ImageCapture.OutputFileOptions {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$FOLDER")
            }
            val contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            androidx.camera.core.ImageCapture.OutputFileOptions.Builder(
                context.contentResolver,
                contentUri,
                contentValues
            ).build()
        } else {
            val file = createImageFile(context)
            androidx.camera.core.ImageCapture.OutputFileOptions.Builder(file).build()
        }
    }

    fun listPhotos(context: Context): List<File> {
        val dir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
            FOLDER
        )
        if (!dir.exists()) return emptyList()
        return dir.listFiles { f -> f.extension.equals("jpg", true) || f.extension.equals("jpeg", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun getPhotoUri(context: Context, file: File): Uri {
        return androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }
}
