package com.aiphotographer.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.aiphotographer.app.R

/**
 * Rule-of-thirds grid overlay for professional composition guidance.
 */
class GridOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.grid_line)
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val thirdW = w / 3f
        val thirdH = h / 3f

        // Vertical lines
        canvas.drawLine(thirdW, 0f, thirdW, h, paint)
        canvas.drawLine(thirdW * 2, 0f, thirdW * 2, h, paint)

        // Horizontal lines
        canvas.drawLine(0f, thirdH, w, thirdH, paint)
        canvas.drawLine(0f, thirdH * 2, w, thirdH * 2, paint)
    }
}
