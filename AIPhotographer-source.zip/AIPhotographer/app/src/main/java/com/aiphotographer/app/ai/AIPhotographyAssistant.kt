package com.aiphotographer.app.ai

import android.graphics.Rect
import android.util.Log
import androidx.camera.core.ImageProxy
import com.aiphotographer.app.AIPhotographerApp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * On-device AI photography assistant.
 * Uses ML Kit Face Detection and Pose Detection for real-time guidance.
 * Processes only the latest frame for low latency and battery efficiency.
 */
class AIPhotographyAssistant {

    private val faceDetector: FaceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.15f)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private val poseDetector: PoseDetector by lazy {
        val options = PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
        PoseDetection.getClient(options)
    }

    private var lastSuggestionTime = 0L
    private var lastSuggestion = ""
    private val suggestionThrottleMs = 1200L

    data class AnalysisResult(
        val suggestion: String,
        val faces: List<Face> = emptyList(),
        val hasPose: Boolean = false,
        val brightnessHint: String? = null,
        val compositionScore: Float = 0.5f
    )

    /**
     * Analyze the latest camera frame and return photography guidance.
     * Must be called from a background thread / executor.
     * Caller is responsible for closing ImageProxy after this returns.
     */
    suspend fun analyze(imageProxy: ImageProxy, isFrontCamera: Boolean, mode: PhotoMode): AnalysisResult {
        val mediaImage = imageProxy.image ?: return AnalysisResult("Camera frame unavailable")
        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        return try {
            val faces = faceDetector.process(inputImage).await()
            val suggestion = generateSuggestion(faces, imageProxy, isFrontCamera, mode)
            AnalysisResult(
                suggestion = suggestion,
                faces = faces,
                compositionScore = estimateComposition(faces, imageProxy.width, imageProxy.height)
            )
        } catch (e: Exception) {
            Log.w(AIPhotographerApp.TAG, "AI analysis error: ${e.message}")
            AnalysisResult("Analyzing scene…")
        }
    }

    private fun generateSuggestion(
        faces: List<Face>,
        imageProxy: ImageProxy,
        isFrontCamera: Boolean,
        mode: PhotoMode
    ): String {
        val now = System.currentTimeMillis()
        if (now - lastSuggestionTime < suggestionThrottleMs && lastSuggestion.isNotEmpty()) {
            return lastSuggestion
        }

        val w = imageProxy.width.toFloat()
        val h = imageProxy.height.toFloat()
        val suggestion = when {
            faces.isEmpty() && mode != PhotoMode.LANDSCAPE && mode != PhotoMode.FOOD -> {
                when (mode) {
                    PhotoMode.PORTRAIT, PhotoMode.SELFIE -> "Frame your face or subject in the viewfinder."
                    PhotoMode.STREET -> "Look for interesting subjects or moments."
                    else -> "Point the camera at your subject."
                }
            }
            faces.isNotEmpty() -> analyzeFaces(faces, w, h, isFrontCamera, mode)
            else -> modeSpecificAdvice(mode)
        }

        lastSuggestion = suggestion
        lastSuggestionTime = now
        return suggestion
    }

    private fun analyzeFaces(
        faces: List<Face>,
        frameW: Float,
        frameH: Float,
        isFrontCamera: Boolean,
        mode: PhotoMode
    ): String {
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return "No face detected."
        val box = face.boundingBox
        val faceCenterX = box.centerX() / frameW
        val faceCenterY = box.centerY() / frameH
        val faceAreaRatio = (box.width() * box.height()) / (frameW * frameH)

        // Size / distance guidance
        if (faceAreaRatio < 0.08f) {
            return "Move slightly closer."
        }
        if (faceAreaRatio > 0.45f && mode != PhotoMode.MACRO) {
            return "Step back a little."
        }

        // Rule of thirds: ideal near 1/3 or 2/3
        val nearThirdX = abs(faceCenterX - 0.33f) < 0.12f || abs(faceCenterX - 0.67f) < 0.12f
        val nearThirdY = abs(faceCenterY - 0.33f) < 0.12f || abs(faceCenterY - 0.67f) < 0.12f
        val centered = abs(faceCenterX - 0.5f) < 0.15f && abs(faceCenterY - 0.45f) < 0.15f

        // Headroom
        if (box.top < frameH * 0.05f) {
            return "Leave a little more space above the head."
        }

        // Lighting via smile / eye openness as proxy + classification
        val leftEye = face.leftEyeOpenProbability
        val rightEye = face.rightEyeOpenProbability
        val smiling = face.smilingProbability

        if (leftEye != null && rightEye != null && leftEye < 0.3f && rightEye < 0.3f) {
            return "Eyes look closed. Wait for a natural blink break."
        }

        // Face orientation / lighting direction
        val rotY = face.headEulerAngleY
        if (abs(rotY) > 25f) {
            return "Turn your face slightly toward the camera."
        }

        // Composition feedback
        return when {
            nearThirdX || nearThirdY -> "Excellent composition. Capture now!"
            centered && mode == PhotoMode.PORTRAIT -> "Good centered portrait. Capture when ready."
            !nearThirdX && mode == PhotoMode.PORTRAIT -> "Place the subject near a left or right grid line."
            smiling != null && smiling > 0.7f -> "Great expression! Capture now!"
            else -> modeSpecificAdvice(mode)
        }
    }

    private fun modeSpecificAdvice(mode: PhotoMode): String {
        return when (mode) {
            PhotoMode.PORTRAIT -> "Position subject near a rule-of-thirds intersection."
            PhotoMode.LANDSCAPE -> "Keep the horizon straight and use leading lines."
            PhotoMode.STREET -> "Anticipate the moment. Keep shutter ready."
            PhotoMode.NIGHT -> "Hold steady. Use available light or raise ISO carefully."
            PhotoMode.MACRO -> "Get close and keep the subject sharp."
            PhotoMode.CINEMATIC -> "Leave space in the direction the subject is looking."
            PhotoMode.FOOD -> "Shoot from 45° or overhead. Soft side light works best."
            PhotoMode.SELFIE -> "Hold the camera a little higher and look toward the light."
            PhotoMode.AUTO -> "Compose carefully. AI is ready to guide you."
        }
    }

    private fun estimateComposition(faces: List<Face>, w: Int, h: Int): Float {
        if (faces.isEmpty()) return 0.4f
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return 0.4f
        val cx = face.boundingBox.centerX() / w.toFloat()
        val cy = face.boundingBox.centerY() / h.toFloat()
        val thirdScore = min(
            min(abs(cx - 0.33f), abs(cx - 0.67f)),
            min(abs(cy - 0.33f), abs(cy - 0.67f))
        )
        return (1f - thirdScore * 2f).coerceIn(0.2f, 1f)
    }

    fun close() {
        faceDetector.close()
        poseDetector.close()
    }
}

enum class PhotoMode {
    AUTO, PORTRAIT, LANDSCAPE, STREET, NIGHT, MACRO, CINEMATIC, FOOD, SELFIE
}
