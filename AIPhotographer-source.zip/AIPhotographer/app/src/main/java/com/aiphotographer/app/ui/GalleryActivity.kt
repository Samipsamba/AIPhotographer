package com.aiphotographer.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aiphotographer.app.R
import com.aiphotographer.app.databinding.ActivityGalleryBinding
import com.aiphotographer.app.utils.PhotoStorage
import com.bumptech.glide.Glide
import java.io.File

class GalleryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryBinding
    private lateinit var adapter: PhotoAdapter
    private var photos: MutableList<File> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        adapter = PhotoAdapter(
            onClick = { file -> openPreview(file) },
            onLongClick = { file -> confirmDelete(file) }
        )
        binding.recyclerGallery.layoutManager = GridLayoutManager(this, 3)
        binding.recyclerGallery.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        loadPhotos()
    }

    private fun loadPhotos() {
        photos = PhotoStorage.listPhotos(this).toMutableList()
        adapter.submit(photos)
        binding.tvEmpty.visibility = if (photos.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openPreview(file: File) {
        val intent = Intent(this, EditActivity::class.java).apply {
            putExtra(EditActivity.EXTRA_PATH, file.absolutePath)
        }
        startActivity(intent)
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete)
            .setMessage(R.string.confirm_delete)
            .setPositiveButton(R.string.yes) { _, _ ->
                if (file.delete()) {
                    photos.remove(file)
                    adapter.submit(photos)
                    binding.tvEmpty.visibility = if (photos.isEmpty()) View.VISIBLE else View.GONE
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    private class PhotoAdapter(
        private val onClick: (File) -> Unit,
        private val onLongClick: (File) -> Unit
    ) : RecyclerView.Adapter<PhotoAdapter.VH>() {

        private var items: List<File> = emptyList()

        fun submit(list: List<File>) {
            items = list
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val file = items[position]
            Glide.with(holder.img).load(file).centerCrop().into(holder.img)
            holder.itemView.setOnClickListener { onClick(file) }
            holder.itemView.setOnLongClickListener {
                onLongClick(file)
                true
            }
        }

        override fun getItemCount() = items.size

        class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val img: ImageView = itemView.findViewById(R.id.imgPhoto)
        }
    }
}
