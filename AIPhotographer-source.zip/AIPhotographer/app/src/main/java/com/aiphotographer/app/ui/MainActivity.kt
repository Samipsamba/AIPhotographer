package com.aiphotographer.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.ImageCapture
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.aiphotographer.app.R
import com.aiphotographer.app.ai.AIPhotographyAssistant
import com.aiphotographer.app.ai.PhotoMode
import com.aiphotographer.app.camera.CameraManager
import com.aiphotographer.app.camera.PhotoModeHelper
import com.aiphotographer.app.databinding.ActivityMainBinding
import com.aiphotographer.app.utils.PhotoStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var cameraManager: CameraManager? = null
    private val aiAssistant = AIPhotographyAssistant()
    private var currentMode = PhotoMode.AUTO
    private var timerSeconds = 0 // 0 = off, 3, 5, 10
    private var isAnalyzing = false
    private var scaleDetector: ScaleGestureDetector? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val cameraGranted = results[Manifest.permission.CAMERA] == true
        if (cameraGranted) {
            startCamera()
        } else {
            Toast.makeText(this, R.string.camera_permission_required, Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        checkPermissionsAndStart()
    }

    private fun setupUI() {
        binding.btnCapture.setOnClickListener { onCaptureClicked() }
        binding.btnSwitchCamera.setOnClickListener {
            cameraManager?.switchCamera()
            if (cameraManager?.isFrontCamera() == true) {
                currentMode = PhotoMode.SELFIE
                binding.chipSelfie.isChecked = true
            }
        }
        binding.btnFlash.setOnClickListener { cycleFlash() }
        binding.btnGrid.setOnClickListener { toggleGrid() }
        binding.btnTimer.setOnClickListener { cycleTimer() }
        binding.btnGallery.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        // Mode chips
        binding.chipAuto.setOnClickListener { setMode(PhotoMode.AUTO) }
        binding.chipPortrait.setOnClickListener { setMode(PhotoMode.PORTRAIT) }
        binding.chipLandscape.setOnClickListener { setMode(PhotoMode.LANDSCAPE) }
        binding.chipStreet.setOnClickListener { setMode(PhotoMode.STREET) }
        binding.chipNight.setOnClickListener { setMode(PhotoMode.NIGHT) }
        binding.chipMacro.setOnClickListener { setMode(PhotoMode.MACRO) }
        binding.chipCinematic.setOnClickListener { setMode(PhotoMode.CINEMATIC) }
        binding.chipFood.setOnClickListener { setMode(PhotoMode.FOOD) }
        binding.chipSelfie.setOnClickListener {
            setMode(PhotoMode.SELFIE)
            if (cameraManager?.isFrontCamera() != true) {
                cameraManager?.switchCamera()
            }
        }

        // Exposure seekbar (mapped -2 .. +2 EV approx)
        binding.seekExposure.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val index = progress - 12 // center at 12
                cameraManager?.setExposureCompensation(index)
                val step = cameraManager?.getExposureStep() ?: 0.33f
                val ev = index * step
                binding.tvExposure.text = "EV %+.1f".format(ev)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })

        // Zoom seekbar
        binding.seekZoom.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val maxZ = cameraManager?.getMaxZoom() ?: 4f
                val ratio = 1f + (progress / 100f) * (maxZ - 1f)
                cameraManager?.setZoomRatio(ratio)
                binding.tvZoom.text = "%.1fx".format(ratio)
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })

        // Tap to focus
        binding.previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                cameraManager?.setFocusAt(event.x, event.y)
            }
            scaleDetector?.onTouchEvent(event)
            true
        }

        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val current = cameraManager?.let {
                    // approximate from seekbar
                    val maxZ = it.getMaxZoom()
                    1f + (binding.seekZoom.progress / 100f) * (maxZ - 1f)
                } ?: 1f
                val newZoom = (current * detector.scaleFactor).coerceIn(1f, cameraManager?.getMaxZoom() ?: 4f)
                cameraManager?.setZoomRatio(newZoom)
                val maxZ = cameraManager?.getMaxZoom() ?: 4f
                binding.seekZoom.progress = ((newZoom - 1f) / (maxZ - 1f) * 100).toInt().coerceIn(0, 100)
                binding.tvZoom.text = "%.1fx".format(newZoom)
                return true
            }
        })
    }

    private fun checkPermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= 28) {
            needed.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (Build.VERSION.SDK_INT in 33..Int.MAX_VALUE) {
            needed.add(Manifest.permission.READ_MEDIA_IMAGES)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startCamera()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startCamera() {
        cameraManager = CameraManager(this, this, binding.previewView).also { mgr ->
            mgr.onAnalysisFrame = { imageProxy ->
                if (!isAnalyzing) {
                    isAnalyzing = true
                    lifecycleScope.launch(Dispatchers.Default) {
                        try {
                            val result = aiAssistant.analyze(
                                imageProxy,
                                mgr.isFrontCamera(),
                                currentMode
                            )
                            withContext(Dispatchers.Main) {
                                binding.aiSuggestionText.text = result.suggestion
                            }
                        } finally {
                            imageProxy.close()
                            isAnalyzing = false
                        }
                    }
                } else {
                    imageProxy.close()
                }
            }
            mgr.onError = { msg ->
                runOnUiThread {
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
            mgr.startCamera()
        }
        updateFlashButtonVisibility()
    }

    private fun setMode(mode: PhotoMode) {
        currentMode = mode
        val config = PhotoModeHelper.getConfig(mode)
        binding.aiSuggestionText.text = config.advice
        if (config.preferFront && cameraManager?.isFrontCamera() != true) {
            cameraManager?.switchCamera()
        }
    }

    private fun cycleFlash() {
        val mode = cameraManager?.cycleFlashMode() ?: ImageCapture.FLASH_MODE_OFF
        val label = when (mode) {
            ImageCapture.FLASH_MODE_ON -> "Flash On"
            ImageCapture.FLASH_MODE_AUTO -> "Flash Auto"
            else -> "Flash Off"
        }
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
    }

    private fun toggleGrid() {
        val visible = !binding.gridOverlay.isVisible
        binding.gridOverlay.isVisible = visible
        Toast.makeText(this, if (visible) "Grid On" else "Grid Off", Toast.LENGTH_SHORT).show()
    }

    private fun cycleTimer() {
        timerSeconds = when (timerSeconds) {
            0 -> 3
            3 -> 5
            5 -> 10
            else -> 0
        }
        val msg = if (timerSeconds == 0) "Timer Off" else "Timer ${timerSeconds}s"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun onCaptureClicked() {
        if (timerSeconds > 0) {
            startCountdown(timerSeconds)
        } else {
            takePhoto()
        }
    }

    private fun startCountdown(seconds: Int) {
        binding.tvCountdown.visibility = View.VISIBLE
        object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                binding.tvCountdown.text = ((millisUntilFinished / 1000) + 1).toString()
            }
            override fun onFinish() {
                binding.tvCountdown.visibility = View.GONE
                takePhoto()
            }
        }.start()
    }

    private fun takePhoto() {
        val options = PhotoStorage.createOutputOptions(this)
        cameraManager?.takePicture(
            options,
            onSuccess = {
                Toast.makeText(this, R.string.photo_saved, Toast.LENGTH_SHORT).show()
                // Brief shutter feedback
                binding.previewView.alpha = 0.3f
                binding.previewView.animate().alpha(1f).setDuration(150).start()
            },
            onError = { e ->
                Toast.makeText(this, getString(R.string.photo_failed) + ": ${e.message}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun updateFlashButtonVisibility() {
        binding.btnFlash.isEnabled = cameraManager?.hasFlash() == true
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraManager?.shutdown()
        aiAssistant.close()
    }
}
